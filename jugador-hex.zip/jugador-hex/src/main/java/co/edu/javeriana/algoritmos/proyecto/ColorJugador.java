/**
 * 
 */
package co.edu.javeriana.algoritmos.proyecto;

/**
 * Enum que representa los posibles valores para el color de un jugador.
 * 
 * NO MODIFIQUE NADA EN ESTE ARCHIVO, NI LO COPIE, NI LO MUEVA A OTRO PAQUETE.
 *
 */
public enum ColorJugador 
{
    NEGRO(0), BLANCO(1);

    int numero;
    
    ColorJugador( int numero )
    {
        this.numero = numero;
    }

}
